<?php

namespace Diepxuan\Magento\Exceptions;

class MagentoClientException extends \Exception
{
}