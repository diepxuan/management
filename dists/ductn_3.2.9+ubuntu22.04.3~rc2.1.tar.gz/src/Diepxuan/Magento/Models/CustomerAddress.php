<?php

namespace Diepxuan\Magento\Models;


use Diepxuan\Magento\Utils\Model;

class CustomerAddress extends Model
{
    protected $entity     = 'customers/addresses';
    protected $primaryKey = 'id';
}