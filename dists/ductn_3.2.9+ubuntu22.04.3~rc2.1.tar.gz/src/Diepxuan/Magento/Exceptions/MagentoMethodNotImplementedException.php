<?php

namespace Diepxuan\Magento\Exceptions;

class MagentoMethodNotImplementedException extends \Exception
{
}