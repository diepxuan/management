# DiepXuan DXPanel Foudation system

<p align="center">
    <a href="https://packagist.org/packages/diepxuan/system">
        <img src="https://img.shields.io/packagist/dt/diepxuan/system.svg?style=flat-square" alt="Total Downloads">
    </a>
    <a href="https://packagist.org/packages/diepxuan/system">
        <img src="https://img.shields.io/packagist/v/diepxuan/system.svg?style=flat-square" alt="Latest Stable Version">
    </a>
    <a href="https://packagist.org/packages/diepxuan/system">
        <img src="https://img.shields.io/packagist/l/diepxuan/system.svg?style=flat-square" alt="License">
    </a>
</p>

## Installation

### Require using composer

```bash
composer require diepxuan/system
```
