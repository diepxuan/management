<?php

namespace Diepxuan\Magento\Models;

use Diepxuan\Magento\Utils\Model;

class Order extends Model
{
    protected $entity     = 'orders';
    protected $primaryKey = 'entity_id';
}