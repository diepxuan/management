#!/usr/bin/env bash
#!/bin/bash

--server:install() {
    --sys:apt:install php
}
