#!/usr/bin/env bash
#!/bin/bash

TXTtrue=[${Green}✓$NC]
TXTfalse=[${Red}✗$NC]
TXTinfo=[${Yellow}i$NC]
