<?php

namespace Diepxuan\Magento\Models;


use Diepxuan\Magento\Utils\Model;

class CustomerGroup extends Model
{
    protected $entity     = 'customerGroups';
    protected $primaryKey = 'id';
}