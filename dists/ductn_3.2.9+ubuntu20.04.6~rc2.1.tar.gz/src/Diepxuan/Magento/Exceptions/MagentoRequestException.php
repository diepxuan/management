<?php

namespace Diepxuan\Magento\Exceptions;

class MagentoRequestException extends \Exception
{
}